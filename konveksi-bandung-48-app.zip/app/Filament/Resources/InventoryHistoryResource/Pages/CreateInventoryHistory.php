<?php

namespace App\Filament\Resources\InventoryHistoryResource\Pages;

use App\Filament\Resources\InventoryHistoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInventoryHistory extends CreateRecord
{
    protected static string $resource = InventoryHistoryResource::class;
}
