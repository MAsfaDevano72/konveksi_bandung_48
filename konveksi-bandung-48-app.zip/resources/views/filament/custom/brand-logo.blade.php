<div class="flex items-center gap-3">
    <img src="{{ asset('images/konveksi_bandung_48.png') }}" alt="Logo" class="h-8">
    <span class="text-lg font-bold tracking-tight text-gray-950 dark:text-white">
        Konveksi Bandung 48
    </span>
</div>