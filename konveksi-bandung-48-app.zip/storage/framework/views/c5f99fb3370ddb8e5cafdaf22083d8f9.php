<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div 
        x-data="{
            scrollToStage() {
                const role = '<?php echo e(auth()->user()->roles->first()->name ?? ''); ?>';
                let targetId = '';

                if (role === 'Cutting') targetId = 'status-Cutting';
                if (role === 'Tailor') targetId = 'status-Sewing';
                if (role === 'QC/Packing') targetId = 'status-QC/Packing';

                if (targetId) {
                    const el = document.getElementById(targetId);
                    if (el) {
                        el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                    }
                }
            }
        }" 
        x-init="setTimeout(() => scrollToStage(), 500)"
        wire:ignore.self 
        
        class="flex flex-nowrap overflow-x-auto overflow-y-hidden gap-4 pb-10 snap-x snap-mandatory items-stretch"
        style="WebkitOverflowScrolling: touch;"
    >
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div 
                id="status-<?php echo e($status['id']); ?>" 
                class="snap-center shrink-0 w-[85vw] md:w-[350px] flex flex-col"
            >
                <div class="bg-gray-50 dark:bg-white/5 rounded-xl border border-gray-200 dark:border-white/10 flex flex-col flex-1 shadow-sm">
                    <?php echo $__env->make(static::$statusView, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div wire:ignore class="flex">
            <?php echo $__env->make(static::$scriptsView, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($disableEditModal)): ?>
        <?php if (isset($component)) { $__componentOriginal5dfada62f0dcd3dca2cae76033b65a8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dfada62f0dcd3dca2cae76033b65a8b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-kanban::components.edit-record-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-kanban::edit-record-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dfada62f0dcd3dca2cae76033b65a8b)): ?>
<?php $attributes = $__attributesOriginal5dfada62f0dcd3dca2cae76033b65a8b; ?>
<?php unset($__attributesOriginal5dfada62f0dcd3dca2cae76033b65a8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dfada62f0dcd3dca2cae76033b65a8b)): ?>
<?php $component = $__componentOriginal5dfada62f0dcd3dca2cae76033b65a8b; ?>
<?php unset($__componentOriginal5dfada62f0dcd3dca2cae76033b65a8b); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\konveksi-bandung-48-app\resources\views/vendor/filament-kanban/kanban-board.blade.php ENDPATH**/ ?>