<div class="flex items-center gap-3">
    <img src="<?php echo e(asset('images/konveksi_bandung_48.png')); ?>" alt="Logo" class="h-8">
    <span class="text-lg font-bold tracking-tight text-gray-950 dark:text-white">
        Konveksi Bandung 48
    </span>
</div><?php /**PATH C:\laragon\www\konveksi-bandung-48-app\resources\views/filament/custom/brand-logo.blade.php ENDPATH**/ ?>