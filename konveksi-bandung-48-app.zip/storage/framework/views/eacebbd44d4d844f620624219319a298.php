<h3 class="mb-2 px-4 font-semibold text-lg text-gray-800">
    <span class="text-primary-700 ">❖</span>
    <?php echo e($status['title']); ?>

</h3>
<?php /**PATH C:\laragon\www\konveksi-bandung-48-app\resources\views/vendor/filament-kanban/kanban-header.blade.php ENDPATH**/ ?>